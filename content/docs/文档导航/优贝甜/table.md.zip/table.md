<table border="2" bordercolor="black" width="300" cellspacing="0" cellpadding="5">
        <tr>
          <td>1.1</td>
          <td>1.2</td>
          <td>1.3</td></tr>
        <tr>
          <td>2.1</td>
          <td>2.2</td>
          <td>2.3</td></tr>
        <tr>
          <td>3.1</td>
          <td>3.2</td>
          <td>3.3</td></tr>
</table>

<table border="2" bordercolor="black" width="300" cellspacing="0" cellpadding="5">
        <tr>
          <td colspan="3">1.1</td>
          <!--<td>1.2</td>-->
          <!--<td>1.3</td>--></tr>
        <tr>
          <td>2.1</td>
          <td>2.2</td>
          <td>2.3</td></tr>
        <tr>
          <td>3.1</td>
          <td>3.2</td>
          <td>3.3</td></tr>
</table>

<table border="2" bordercolor="black" width="300" cellspacing="0" cellpadding="5">
        <tr>
          <td rowspan="3">1.1</td>
          <td>1.2</td>
          <td>1.3</td></tr>
        <tr>
          <!--<td>2.1</td>-->
          <td>2.2</td>
          <td>2.3</td></tr>
        <tr>
          <!--<td>3.1</td>-->
          <td>3.2</td>
          <td>3.3</td></tr>
</table>

<table border="2" bordercolor="black" width="300" cellspacing="0" cellpadding="5">
        <tr>
          <td>1.1</td>
          <td colspan="2">1.2</td>
          <!--<td>1.3</td>--></tr>
        <tr>
          <td>2.1</td>
          <td rowspan="2">2.2
            <br/>3.2</td>
          <td>2.3</td></tr>
        <tr>
          <td>3.1</td>
          <!--<td>3.2</td>-->
          <td>3.3</td></tr>
</table>
